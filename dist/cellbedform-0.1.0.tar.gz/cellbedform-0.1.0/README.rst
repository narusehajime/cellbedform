CELLBEDFORM
========================

This is a code for a simple cell model simulation of self-organized bedform. The model is based on Nishimori and Ouchi (1993). 

---------------
Installation

python setup.py sdist

---------------
Test codes

python setup.py test

---------------
Usage

After installation, use the following commands.

> from cellbedform import CellBedform
> cb = CellBedform(grid=(100,100))
> cb.run(steps=50)
> cb.show()

This will show calculation results by surface plot. If you would like to store
results as a image sequence

> cb.animation(filename='bedform.gif', format='gif')




